<!DOCTYPE html>
<html lang = "en-US">
 <head>
 <meta charset = "UTF-8">
 <title>test.php</title>
 </head>
 <body>
 <h1>Getting the Time, PHP Style</h1>
	 <p>Seite abgerufen am </p>
  <?php 
	$test = "Hello, World!";
	Print "$test"; 
	 ?>
	 <script>
	 document.write("Ba-Na-Nee");
	 document.write("<?php echo $test ?>");
		 </script>
 </body>
</html>