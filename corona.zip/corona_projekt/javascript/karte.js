var karte = document.getElementById("deutschland");

function klick(){
    bewegeElement();
}

function bewegeElement(){
    karte.style.transform = "translate(-34vw, 0)";
}
//karte.style.position = "absolute";
//karte.style.left = pos_x + "px";
//karte.style.top = pos_y + "vh";